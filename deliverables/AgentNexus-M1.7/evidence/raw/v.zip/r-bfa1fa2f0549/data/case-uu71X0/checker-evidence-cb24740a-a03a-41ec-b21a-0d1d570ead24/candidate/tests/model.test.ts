import test from 'node:test'; import assert from 'node:assert/strict'; import {double} from '../src/model.ts';
test('double',()=>assert.equal(double(2),4));
console.log('x'.repeat(20000));
