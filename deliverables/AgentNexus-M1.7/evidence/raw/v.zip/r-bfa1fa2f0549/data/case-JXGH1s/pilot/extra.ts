throw Error("not an input");
