Trusted fixed checker fixture. No Provider or OS qualification.
