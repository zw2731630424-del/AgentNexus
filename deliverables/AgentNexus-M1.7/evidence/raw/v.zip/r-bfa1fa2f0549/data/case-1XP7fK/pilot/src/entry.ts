import { run } from './cli.ts';
let input=''; for await(const bytes of process.stdin)input+=String(bytes); process.stdout.write(run(input)+'\n');
