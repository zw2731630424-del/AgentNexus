import test from 'node:test'; import assert from 'node:assert/strict'; import {total} from '../src/analytics.ts';
test('total',()=>assert.equal(total([1,2]),6));
