import { total } from './analytics.ts';
export function run(raw:string):string { const values:unknown=JSON.parse(raw); if(!Array.isArray(values)||!values.every(v=>typeof v==='number'&&Number.isFinite(v)))throw Error('invalid'); return JSON.stringify({total:total(values)}); }
