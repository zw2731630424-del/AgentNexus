import { double } from './model.ts';
export function total(values:readonly number[]):number { return values.reduce((n,v)=>n+double(v),0); }
