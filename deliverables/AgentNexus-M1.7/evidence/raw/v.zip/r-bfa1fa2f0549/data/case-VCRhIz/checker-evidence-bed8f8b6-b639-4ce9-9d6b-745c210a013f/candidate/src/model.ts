export function double(value:number):number { return 'wrong'; }
