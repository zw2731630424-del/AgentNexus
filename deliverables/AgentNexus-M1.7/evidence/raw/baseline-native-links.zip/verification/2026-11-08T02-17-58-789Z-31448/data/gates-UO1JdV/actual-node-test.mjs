import test from 'node:test';import assert from 'node:assert/strict';test('actual arithmetic',()=>assert.equal(2+2,4));
