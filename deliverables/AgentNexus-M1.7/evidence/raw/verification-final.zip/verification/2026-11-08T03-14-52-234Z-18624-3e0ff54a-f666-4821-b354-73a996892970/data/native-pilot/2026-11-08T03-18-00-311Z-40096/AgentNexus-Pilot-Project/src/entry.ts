import {open,readFile,rename,unlink} from 'node:fs/promises';
import {resolve} from 'node:path';
import {run} from './cli.ts';
const [flag,name,...args]=process.argv.slice(2);
if(flag!=='--data'||!name){console.error('Usage: node src/entry.ts --data <file.json> <command>');process.exitCode=2;}
else {const path=resolve(name),lockPath=path+'.lock',temp=path+'.tmp-'+process.pid;let lock:Awaited<ReturnType<typeof open>>|null=null,tempOwned=false;
  try {lock=await open(lockPath,'wx');let raw:string|null=null;try{raw=await readFile(path,'utf8');}catch(e){if((e as NodeJS.ErrnoException).code!=='ENOENT')throw e;}
    const result=run(args,raw);
    if(result.exit_code===0&&result.state!==raw){const file=await open(temp,'wx');tempOwned=true;try{await file.writeFile(result.state!,'utf8');await file.sync();}finally{await file.close();}await rename(temp,path);tempOwned=false;}
    console.log(result.stdout);process.exitCode=result.exit_code;
  }catch(e){console.error(JSON.stringify({error:(e as NodeJS.ErrnoException).code??'IO_ERROR'}));process.exitCode=3;}
  finally{if(tempOwned)await unlink(temp);if(lock){await lock.close();await unlink(lockPath);}}
}
