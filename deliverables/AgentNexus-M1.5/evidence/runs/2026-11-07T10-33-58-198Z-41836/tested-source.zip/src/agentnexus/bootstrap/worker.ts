import { readFile } from 'node:fs/promises';
import { createPublicKey } from 'node:crypto';
import { canonical, invariant, sha256 } from '../types.ts';
import { keys } from '../runtime/contracts.ts';
import { authenticated, DeadlineGuard, validateGrant } from '../production/contracts.ts';
import type { Grant, Signed } from '../production/contracts.ts';
import type { Json } from '../types.ts';

export function digestArguments(value:Json):{data_base64:string}{
  keys(value,['data_base64']);const a=value as {data_base64:string};invariant(typeof a.data_base64==='string'&&a.data_base64.length<=10924,'M15_DIGEST_LIMIT');
  const bytes=Buffer.from(a.data_base64,'base64');invariant(bytes.length<=8192&&bytes.toString('base64')===a.data_base64,'M15_DIGEST_ENCODING');return a;
}
export function executeFiniteWorker(packet:unknown,publicKey:string,pid:number):{sha256:string;bytes:number;operation_id:string;worker_instance_id:string}{
  keys(packet,['schema','permit','arguments']);const p=packet as {schema:string;permit:Signed<Grant>;arguments:Json};invariant(p.schema==='agentnexus/worker-bootstrap/1','M15_WORKER_SCHEMA');
  const g=authenticated(p.permit,createPublicKey(publicKey));validateGrant(g);new DeadlineGuard().check(g.issued_at,g.expires_at);
  invariant(g.process.pid===pid&&g.tool_id==='nexus.digest'&&g.tool_version==='1'&&g.arguments_hash===sha256(canonical(p.arguments)),'M15_WORKER_BINDING');
  const data=Buffer.from(digestArguments(p.arguments).data_base64,'base64');return {sha256:sha256(data),bytes:data.length,operation_id:g.operation_id,worker_instance_id:g.worker_instance_id};
}
export async function workerMain():Promise<void>{
  const args=process.argv.slice(2);invariant(args.length===4&&args[0]==='--host-key'&&args[2]==='--key-sha256','M15_WORKER_ARGUMENTS');
  const keyBytes=await readFile(args[1]!);invariant(sha256(keyBytes)===args[3],'M15_WORKER_KEY_CHANGED');
  const chunks:Buffer[]=[];let size=0;for await(const chunk of process.stdin){const bytes=Buffer.from(chunk as Uint8Array);size+=bytes.length;invariant(size<=16384,'M15_WORKER_BOOTSTRAP_LIMIT');chunks.push(bytes);}
  const raw=new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks)),packet:unknown=JSON.parse(raw);invariant(canonical(packet)===raw,'M15_WORKER_NONCANONICAL');
  const result=executeFiniteWorker(packet,keyBytes.toString('utf8'),process.pid);await new Promise<void>((resolve,reject)=>process.stdout.write(canonical(result)+'\n',error=>error?reject(error):resolve()));
}
// Importing argument/schema helpers never runs a task.
if(process.argv[1]&&new URL(import.meta.url).pathname.toLowerCase().endsWith(process.argv[1].replaceAll('\\','/').split('/').at(-1)!.toLowerCase())){
  void workerMain().catch(()=>{process.stderr.write('WORKER_BOOTSTRAP_REJECTED\n');process.exitCode=2;});
}
