import type { KeyObject } from 'node:crypto';
import { canonical, invariant, NexusError, sha256, uid } from '../types.ts';
import type { Json } from '../types.ts';
import { keys, profileHash, sameProcess, snapshot, validateLogical } from '../runtime/contracts.ts';
import type { LogicalIdentity, ProcessIdentity, SandboxProfile } from '../runtime/contracts.ts';
import { authenticated, grantMatches, validateGrant, validateRuntime } from '../production/contracts.ts';
import type { Grant, Runtime, Signed } from '../production/contracts.ts';
import type { IdentityObserver } from '../production/identity.ts';
import type { ProcessSupervisor, SupervisedRun } from '../production/broker.ts';
import type { ExitEvidence } from '../production/exit.ts';
import { WindowsSupervisor } from '../production/windows-supervisor.ts';
import { digestArguments } from './worker.ts';
import { AuthenticatedSession, LauncherLink } from './session.ts';

type Prepared={id:string;process:ProcessIdentity;parent:ProcessIdentity;profile_hash:string;arguments_hash:string;logical:LogicalIdentity;runtime:string|null};
class StreamSlot implements AsyncIterable<Uint8Array>{
  #value:{bytes:Buffer;done:()=>void}|null=null;#wake:(()=>void)|null=null;#ended=false;#error:unknown;
  async push(bytes:Buffer):Promise<void>{invariant(!this.#ended&&!this.#value&&bytes.length<=4096,'M15_OUTPUT_BACKPRESSURE');await new Promise<void>(done=>{this.#value={bytes,done};this.#wake?.();this.#wake=null;});}
  end(error?:unknown):void{this.#ended=true;this.#error=error;this.#value?.done();this.#wake?.();this.#wake=null;}
  async *[Symbol.asyncIterator](){try{for(;;){if(this.#value){const v=this.#value;this.#value=null;try{yield v.bytes;}finally{v.done();}continue;}if(this.#error)throw this.#error;if(this.#ended)return;await new Promise<void>(resolve=>{this.#wake=resolve;});}}finally{this.end(new NexusError('M15_OUTPUT_CONSUMER_CLOSED'));}}
}

/** Host-side owner: process identities originate exclusively from the authenticated Launcher. */
export class RemoteSupervisor implements ProcessSupervisor,IdentityObserver{
  readonly helper_hash:string;readonly link:LauncherLink;#profile:SandboxProfile;#prepared=new Map<object,Prepared>();#runtimes=new Map<string,Prepared>();#grants=new Map<string,Signed<Grant>>();#hostKey:KeyObject;
  constructor(link:LauncherLink,helperHash:string,profile:SandboxProfile,hostPublicKey:KeyObject){this.link=link;this.helper_hash=helperHash;this.#profile=snapshot(profile);this.#hostKey=hostPublicKey;}
  async prepare(logical:LogicalIdentity,args:Json):Promise<object>{
    validateLogical(logical);digestArguments(args);invariant(this.#prepared.size<4,'M15_PREPARE_LIMIT');
    const p=snapshot(await this.link.call('PREPARE',{logical,arguments:args},uid(),Date.now()+10000)) as unknown as Prepared;
    keys(p,['id','process','parent','profile_hash','arguments_hash','logical','runtime']);
    invariant(p.profile_hash===profileHash(this.#profile)&&p.arguments_hash===sha256(canonical(args))&&canonical(p.logical)===canonical(logical)&&p.runtime===null&&p.process.principal===this.#profile.principal,'M15_PREPARED_BINDING');
    const handle=Object.freeze({});this.#prepared.set(handle,{...p});return handle;
  }
  async inspect(handle:object,signal?:AbortSignal){
    const p=this.#prepared.get(handle);invariant(p,'M15_PREPARED_UNKNOWN');
    const o=await this.link.call('INSPECT',{id:p.id},p.id,Date.now()+1500,signal) as unknown as {process:ProcessIdentity;parent:ProcessIdentity;alive:boolean;profile_hash:string;assurance:'REAL_WINDOWS'};
    invariant(sameProcess(o.process,p.process)&&sameProcess(o.parent,p.parent)&&o.profile_hash===p.profile_hash&&o.assurance==='REAL_WINDOWS','M15_PREPARED_CHANGED');return snapshot(o);
  }
  attach(runtime:Runtime,handle:object):void{const p=this.#prepared.get(handle);invariant(p&&p.runtime===null&&sameProcess(runtime.process,p.process)&&sameProcess(runtime.parent,p.parent)&&canonical(runtime.logical)===canonical(p.logical)&&runtime.profile_hash===p.profile_hash,'M15_ATTACH_BINDING');p.runtime=runtime.runtime_id;this.#runtimes.set(runtime.runtime_id,p);}
  registerGrant(packet:Signed<Grant>):void{const g=authenticated(packet,this.#hostKey);validateGrant(g);invariant(this.#runtimes.has(g.runtime_id)&&!this.#grants.has(g.runtime_id),'M15_GRANT_BINDING');this.#grants.set(g.runtime_id,snapshot(packet));}
  async ready(runtime:Runtime,g:Grant,args:Json,signal:AbortSignal):Promise<void>{
    const p=this.#runtimes.get(runtime.runtime_id),packet=this.#grants.get(runtime.runtime_id);invariant(p&&packet&&canonical(packet.body)===canonical(g)&&p.arguments_hash===g.arguments_hash,'M15_READY_BINDING');
    await this.link.call('AUTHORIZE',{id:p.id,runtime,permit:packet,arguments:args},g.operation_id,Math.min(g.expires_at,Date.now()+1800),signal);
  }
  start(runtime:Runtime,g:Grant,args:Json):SupervisedRun{
    const p=this.#runtimes.get(runtime.runtime_id);invariant(p&&this.#grants.has(runtime.runtime_id)&&p.arguments_hash===sha256(canonical(args))&&Date.now()<g.expires_at,'M15_START_BINDING');
    const stdout=new StreamSlot(),stderr=new StreamSlot();
    const exit=this.link.call('START',{id:p.id,operation_id:g.operation_id},g.operation_id,Date.now()+runtime.profile.limits.wall_ms,undefined,async event=>{
      keys(event,['stream','data_base64']);const e=event as {stream:string;data_base64:string};invariant(['stdout','stderr'].includes(e.stream)&&typeof e.data_base64==='string'&&e.data_base64.length<=5464,'M15_OUTPUT_FRAME');const bytes=Buffer.from(e.data_base64,'base64');invariant(bytes.length<=4096&&bytes.toString('base64')===e.data_base64,'M15_OUTPUT_FRAME');await(e.stream==='stdout'?stdout:stderr).push(bytes);
    }).then(result=>{const evidence=snapshot(result) as unknown as ExitEvidence;invariant(evidence.source==='REAL_WINDOWS'&&sameProcess(evidence.process,runtime.process)&&sameProcess(evidence.parent,runtime.parent),'M15_EXIT_BINDING');stdout.end();stderr.end();if(evidence.root_exited&&evidence.job_empty&&Object.values(evidence.outputs).every(o=>o.eof&&o.producer_closed)){this.#runtimes.delete(runtime.runtime_id);this.#grants.delete(runtime.runtime_id);for(const [h,item] of this.#prepared)if(item===p)this.#prepared.delete(h);}return evidence;},error=>{stdout.end(error);stderr.end(error);throw error;});void exit.catch(()=>{});
    return {stdout,stderr,exit,terminate:()=>{this.link.close();stdout.end(new NexusError('M15_TERMINATION_REQUESTED'));stderr.end(new NexusError('M15_TERMINATION_REQUESTED'));}};
  }
  close():void{this.link.close();}
}

type LauncherPrepared={handle:object;logical:LogicalIdentity;args:Json;runtime:Runtime|null;grant:Grant|null;used:boolean};
export class WorkerLauncherService {
  #session:AuthenticatedSession;#supervisor:WindowsSupervisor;#profile:SandboxProfile;#hostSid:string;#hostKey:KeyObject;#entries=new Map<string,LauncherPrepared>();
  constructor(session:AuthenticatedSession,supervisor:WindowsSupervisor,profile:SandboxProfile,hostSid:string,hostKey:KeyObject){this.#session=session;this.#supervisor=supervisor;this.#profile=snapshot(profile);this.#hostSid=hostSid;this.#hostKey=hostKey;}
  async serve(signal:AbortSignal):Promise<void>{
    try{while(!signal.aborted){
      const request=await this.#session.receive(Date.now()+30000,signal);let result:Json;
      try{const payload=request.payload;
        switch(request.kind){
          case 'PREPARE':{
            keys(payload,['logical','arguments']);const p=payload as {logical:LogicalIdentity;arguments:Json};validateLogical(p.logical);digestArguments(p.arguments);invariant(this.#entries.size<4,'M15_LAUNCHER_LIMIT');
            const handle=await this.#supervisor.prepare('nexus.digest',p.arguments,this.#profile,this.#hostSid,this.#profile.principal),observed=await this.#supervisor.inspect(handle),id=uid();
            this.#entries.set(id,{handle,logical:snapshot(p.logical),args:snapshot(p.arguments),runtime:null,grant:null,used:false});
            result={id,process:observed.process,parent:observed.parent,profile_hash:observed.profile_hash,arguments_hash:sha256(canonical(p.arguments)),logical:p.logical,runtime:null};break;
          }
          case 'INSPECT':{keys(payload,['id']);const p=this.#get((payload as {id:string}).id);result=await this.#supervisor.inspect(p.handle);break;}
          case 'AUTHORIZE':{
            keys(payload,['id','runtime','permit','arguments']);const p=payload as {id:string;runtime:Runtime;permit:Signed<Grant>;arguments:Json},entry=this.#get(p.id);
            const g=authenticated(p.permit,this.#hostKey);validateGrant(g);validateRuntime(p.runtime);grantMatches(g,p.runtime,{policy_epoch:g.policy_epoch,feature_epoch:g.feature_epoch});
            invariant(!entry.used&&entry.grant===null&&g.operation_id===request.operation_id&&canonical(entry.logical)===canonical(g.logical)&&canonical(entry.args)===canonical(p.arguments)&&g.arguments_hash===sha256(canonical(entry.args))&&p.runtime.profile_hash===profileHash(this.#profile),'M15_LAUNCHER_AUTHORIZATION');
            const observed=await this.#supervisor.inspect(entry.handle);invariant(sameProcess(observed.process,p.runtime.process)&&sameProcess(observed.parent,p.runtime.parent),'M15_LAUNCHER_PROCESS');
            this.#supervisor.attach(p.runtime,entry.handle);this.#supervisor.setBootstrap(p.runtime,Buffer.from(canonical({schema:'agentnexus/worker-bootstrap/1',permit:p.permit,arguments:entry.args})));
            await this.#supervisor.ready(p.runtime,g,entry.args,signal);entry.runtime=snapshot(p.runtime);entry.grant=g;result={authorized:true,operation_id:g.operation_id};break;
          }
          case 'START':{
            keys(payload,['id','operation_id']);const p=payload as {id:string;operation_id:string},entry=this.#get(p.id),r=entry.runtime,g=entry.grant;
            invariant(r&&g&&!entry.used&&p.operation_id===g.operation_id&&request.operation_id===g.operation_id&&Date.now()<g.expires_at,'M15_LAUNCHER_START');entry.used=true;
            const run=this.#supervisor.start(r,g,entry.args);let gate=Promise.resolve(),monitoring=false;
            const monitor=setInterval(()=>{if(monitoring||this.#session.transportBusy)return;monitoring=true;void this.#session.recheck().catch(()=>run.terminate('HOST_PEER_LOST')).finally(()=>{monitoring=false;});},250);
            const pump=async(stream:'stdout'|'stderr',source:AsyncIterable<Uint8Array>)=>{for await(const chunk of source){const event={stream,data_base64:Buffer.from(chunk).toString('base64')};const task=gate.then(()=>this.#session.send('EVENT',event,request.request_id,request.operation_id,request.expires,signal));gate=task;await task;}};
            try{const [, ,evidence]=await Promise.all([pump('stdout',run.stdout),pump('stderr',run.stderr),run.exit]);result=evidence as unknown as Json;if(evidence.root_exited&&evidence.job_empty&&Object.values(evidence.outputs).every(o=>o.eof&&o.producer_closed))this.#entries.delete(p.id);}
            catch(error){run.terminate('IPC_OR_OUTPUT_UNCERTAIN');throw error;}finally{clearInterval(monitor);}break;
          }
          case 'STOP':{keys(payload,[]);this.#supervisor.close();result={termination_requested:true,exit_verified:false};break;}
          case 'PING':{keys(payload,[]);result={alive:true,prepared:this.#entries.size};break;}
          default:throw new NexusError('M15_LAUNCHER_METHOD');
        }
        await this.#session.send('RESULT',result,request.request_id,request.operation_id,request.expires,signal);
      }catch(error){await this.#session.send('ERROR',{reason:error instanceof NexusError?error.code:'LAUNCHER_UNCERTAIN',automatic_retry:false},request.request_id,request.operation_id,request.expires,signal);throw error;}
    }}finally{this.#supervisor.close();this.#session.close();}
  }
  #get(id:string):LauncherPrepared{const entry=this.#entries.get(id);invariant(entry,'M15_PREPARED_UNKNOWN');return entry;}
}
